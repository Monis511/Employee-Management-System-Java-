package strategies;

public interface RoleStrategy {
    void showDashboard();
}
